import AWS from 'aws-sdk';
import dynamoose from 'dynamoose';

// Update AWS configuration
AWS.config.update({
  accessKeyId: 'AKIA3F323ZAFZU6WIQFB',
  secretAccessKey: 'Nwm0eHV3rTxvm8n7TGKLdJhaYM6hs9ID',
  region: 'us-east-1'
});

const cardSchema = new dynamoose.Schema({
  id: { type: String, hashKey: true },
  title: String,
  level: Number,
  type: String,
});

const CardModel = dynamoose.model("CardTable", cardSchema);

export const handler = async (event) => {
  if (!event.body) {
    const response = {
      statusCode: 500,
      body: "Request body missing, unable to create new DB entry",
    };
    return response;
  } else {
    let modelBody = JSON.parse(event.body);

    try {
      const newCard = await CardModel.create(modelBody);
      const response = {
        statusCode: 200,
        body: JSON.stringify(newCard),
      };
      return response;
    } catch (e) {
      console.log(e);
      const response = {
        statusCode: 500,
        body: JSON.stringify(e),
      };
      return response;
    }
  }
};


// import dotenv from 'dotenv';
// import AWS from 'aws-sdk';
// import dynamoose from 'dynamoose';

// dotenv.config();

// AWS.config.update({
//   accessKeyId: process.env.AWS_ACCESS_KEY_ID,
//   secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
//   region: process.env.AWS_REGION
// });

// const cardSchema = new dynamoose.Schema({
//   id: { type: String, hashKey: true },
//   title: String,
//   level: Number,
//   type: String,
// });

// const CardModel = dynamoose.model("CardTable", cardSchema);

// export const handler = async (event) => {
//   if (!event.body) {
//     const response = {
//       statusCode: 500,
//       body: "Request body missing, unable to create new DB entry",
//     };
//     return response;
//   } else {
//     let modelBody = JSON.parse(event.body);

//     try {
//       const newCard = await CardModel.create(modelBody);
//       const response = {
//         statusCode: 200,
//         body: JSON.stringify(newCard),
//       };
//       return response;
//     } catch (e) {
//       console.log(e);
//       const response = {
//         statusCode: 500,
//         body: JSON.stringify(e),
//       };
//       return response;
//     }
//   }
// };
